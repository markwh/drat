## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(fig.width = 7)
options("mc.cores" = 2)


