#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4amhg_mod) {


    class_<rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> >("model_amhg")

    .constructor<SEXP,SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_amhg_namespace::model_amhg, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4amhg_nolatent_mod) {


    class_<rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> >("model_amhg_nolatent")

    .constructor<SEXP,SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_amhg_nolatent_namespace::model_amhg_nolatent, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4manning_mod) {


    class_<rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> >("model_manning")

    .constructor<SEXP,SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_manning_namespace::model_manning, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4manning_amhg_mod) {


    class_<rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> >("model_manning_amhg")

    .constructor<SEXP,SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_manning_amhg_namespace::model_manning_amhg, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4manning_amhg_nolatent_mod) {


    class_<rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> >("model_manning_amhg_nolatent")

    .constructor<SEXP,SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_manning_amhg_nolatent_namespace::model_manning_amhg_nolatent, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4manning_nolatent_mod) {


    class_<rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> >("model_manning_nolatent")

    .constructor<SEXP,SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_manning_nolatent_namespace::model_manning_nolatent, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
