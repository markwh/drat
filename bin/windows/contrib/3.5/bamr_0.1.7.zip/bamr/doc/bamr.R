## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(fig.width = 7)
options("mc.cores" = 2)
knitr::opts_chunk$set(eval = FALSE)

## ---- eval = FALSE-------------------------------------------------------
#  if (!require("devtools")) {
#    install.packages("devtools")
#  }
#  devtools::install_github("markwh/bamr", local = FALSE)
#  library("bamr")

## ---- echo = FALSE-------------------------------------------------------
#  library("bamr")

## ------------------------------------------------------------------------
#  data(Sacramento)
#  attach(Sacramento)

## ------------------------------------------------------------------------
#  Sac_data <- bam_data(w = Sac_w, s = Sac_s, dA = Sac_dA, Qhat = Sac_QWBM)

## ------------------------------------------------------------------------
#  bam_plot(Sac_data)

## ------------------------------------------------------------------------
#  library(ggplot2)
#  bam_plot(Sac_data) + scale_y_log10()

## ------------------------------------------------------------------------
#  Sac_amhg <- bam_data(w = Sac_w, Qhat = Sac_QWBM)
#  
#  bam_plot(Sac_amhg)

## ------------------------------------------------------------------------
#  bam_settings("lowerbound_A0", "upperbound_A0")
#  bam_settings("logQc_hat", "upperbound_logQ")

## ------------------------------------------------------------------------
#  Sac_priors <- bam_priors(bamdata = Sac_data)

## ------------------------------------------------------------------------
#  Sac_priors_mod1 <- bam_priors(bamdata = Sac_data, lowerbound_A0 = 20)

## ------------------------------------------------------------------------
#  Sac_priors_mod2 <- bam_priors(bamdata = Sac_data,
#                               logQc_hat = median(logQ_hat))

## ------------------------------------------------------------------------
#  # Sac_man_amhg <- bam_estimate(bamdata = Sac_data,
#  #                        variant = "manning_amhg")

## ------------------------------------------------------------------------
#  # Sac_amhg <- bam_estimate(bamdata = Sac_data,
#  #                   bampriors = bam_priors(bamdata = Sac_data,
#  #                                          upperbound_logQ = log(5000)),
#  #                   variant = "amhg")

## ------------------------------------------------------------------------
#  # bam_hydrograph(fit = Sac_man_amhg)
#  # bam_hydrograph(fit = Sac_amhg)

## ------------------------------------------------------------------------
#  # bam_hydrograph(fit = Sac_man_amhg, qobs = Sac_Qobs)

## ------------------------------------------------------------------------
#  # val_manning_amhg <- bam_validate(fit = Sac_man_amhg, qobs = Sac_Qobs)
#  
#  # prediction vs. observation
#  bam_plot(val_manning_amhg)
#  
#  # A suite of performance metrics
#  val_manning_amhg$stats

